package com.example.linta.birthdaybash;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by akhil on 08-04-2017.
 */
public class db1 extends SQLiteOpenHelper {
    public static final String dbname="b1reminder";
    public static final String dbtable="add1";
    public static final String col1="id2";
    public static final String col2="name2";
    public static final String col3="phone2";
    public static final String col4="date2";
    public static final String col5="time2";

    public db1(Context context) {

        super(context, dbname, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table add1 " +
                        "( id2 INTEGER PRIMARY KEY AUTOINCREMENT, name2 TEXT, phone2 TEXT, date2 TEXT, time2 TEXT)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS add1");
        onCreate(db);
    }
}

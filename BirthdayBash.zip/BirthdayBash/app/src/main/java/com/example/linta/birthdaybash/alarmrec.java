package com.example.linta.birthdaybash;

/**
 * Created by linta on 4/10/2017.
 */
import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

/**
 * Created by PARU on 07-04-2017.
 */

public class alarmrec extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "reminder", Toast.LENGTH_SHORT).show();
        createNotification(context,"Check BirthdayBash");



    }
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void createNotification(Context context, String msg) {

        // NotificationManager notif = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Notification notify = new Notification.Builder(context.getApplicationContext())
        // .setContentTitle(msg)
        //.setSmallIcon(R.mipmap.ic_launcher1).build();
        // notif.notify(0, notify);

        PendingIntent notificIntent = PendingIntent.getActivity(context,0,new Intent(context,Main3Activity.class),0);


        NotificationCompat.Builder mBuilder =new NotificationCompat.Builder(context)
                .setContentTitle(msg)
                .setSmallIcon(R.mipmap.ic_launcher);

        mBuilder.setContentIntent(notificIntent);
        mBuilder.setDefaults(NotificationCompat.DEFAULT_SOUND | NotificationCompat.DEFAULT_VIBRATE | NotificationCompat.DEFAULT_LIGHTS);
        mBuilder.setAutoCancel(true);
        mBuilder.mActions.clear();
        NotificationManager mNtificationmanager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        mNtificationmanager.notify(1, mBuilder.build());



    }

}

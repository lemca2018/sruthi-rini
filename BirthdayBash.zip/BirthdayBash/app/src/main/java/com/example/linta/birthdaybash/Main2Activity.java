package com.example.linta.birthdaybash;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;


public class Main2Activity extends AppCompatActivity implements View.OnClickListener {
    db1 mydb;
    int d, m, y;
    SQLiteDatabase db;
    int min,ho,sec,ho2,min2,y1,d1,m1;
    SQLiteDatabase Db, db3;
    TextView t;
    TextView t1, t2;
    ListView lv;
    Context mContext;
    EditText name, phone, date11,time1;
    String name33, phone33, date33,time33;
    String tv, nv, nd, nt;
    Button b2;
    Button b3,b4;
    ArrayAdapter<String> ada;
    ArrayList<String> list = new ArrayList<String>();
    AlarmManager alarm_manager;
    PendingIntent pending_Intent;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        name = (EditText) findViewById(R.id.editText);
        phone = (EditText) findViewById(R.id.editText2);
        date11 = (EditText) findViewById(R.id.date11);
        time1 = (EditText) findViewById(R.id.time11);

        b1 = (Button) findViewById(R.id.button);
        b4 = (Button) findViewById(R.id.button3);

        b2 = (Button) findViewById(R.id.time);
        b3 = (Button) findViewById(R.id.button4);

        b2.setOnClickListener(this);
        b3.setOnClickListener(this);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydb = new db1(Main2Activity.this);
                db = mydb.getWritableDatabase();
                name33 = name.getText().toString();
                phone33 = phone.getText().toString();
                date33 = date11.getText().toString();
                time33 = time1.getText().toString();
                ContentValues values = new ContentValues();
                values.put(db1.col2, name33);
                values.put(db1.col3, phone33);
                values.put(db1.col4, date33);
                values.put(db1.col5, time33);
                db.insert("add1", null, values);
                Toast.makeText(Main2Activity.this, "completed.....", Toast.LENGTH_SHORT).show();

                 Calendar calendar=Calendar.getInstance();
                 int  y = calendar.get(Calendar.YEAR);
                // Toast.makeText(Main2Activity.this, ""+y, Toast.LENGTH_SHORT).show();


                Calendar cal = Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());
                cal.clear();
                int m33=m1-1;

                cal.set(Calendar.DATE,d1);  //1-31
                cal.set(Calendar.MONTH,m33);  //first month is 0!!! January is zero!!!
                cal.set(Calendar.YEAR,y);//year...

                cal.set(Calendar.HOUR_OF_DAY,ho2);  //HOUR
                cal.set(Calendar.MINUTE,min2);       //MIN
                cal.set(Calendar.SECOND, 1);
                //int  y = cal.get(Calendar.YEAR);


                // while(cal.getTimeInMillis()<calendar.getTimeInMillis()) {

                   //  y1=y1+1;
                // }
               // cal.set(Calendar.YEAR,y1);
                NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(Main2Activity.this)
                        .setContentText("New message")
                        .setTicker("alert ne message");
                //Long alertTime=Long.valueOf(ttmilli.LongValue());
                //Long alertTime=Long.parseLong(String.valueOf(ttmilli));
                // Long alertTime = new GregorianCalendar().getTimeInMillis() + 10 * ttmilli;
                Intent alertIntent = new Intent(Main2Activity.this,alarmrec.class);
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), PendingIntent.getBroadcast(Main2Activity.this, 1,
                        alertIntent, PendingIntent.FLAG_UPDATE_CURRENT));
                pending_Intent =PendingIntent.getBroadcast(Main2Activity.this,0,alertIntent,PendingIntent.FLAG_UPDATE_CURRENT);

                Intent intent=new Intent(Main2Activity.this,MainActivity.class);
                startActivity(intent);

            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(Main2Activity.this,MainActivity.class);
                startActivity(in);
            }
        });



    }

    @Override
    public void onClick(View v) {
        if (v == b3) {

            final Calendar c = Calendar.getInstance();


            d = c.get(Calendar.DAY_OF_MONTH);
            m = c.get(Calendar.MONTH);
            y = c.get(Calendar.YEAR);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    date11.setText("" + dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    y1=year;
                    d1=dayOfMonth;
                    m1=monthOfYear + 1;

                }
            }, d, m, y);
            datePickerDialog.show();

        }
        if (v == b2) {
            Calendar c = Calendar.getInstance();

            min = c.get(Calendar.MINUTE);
            ho = c.get(Calendar.HOUR_OF_DAY);
            sec=c.get(Calendar.SECOND);
            TimePickerDialog timePickerDialog=new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    time1.setText("" + hourOfDay + ":" + minute);
                    ho2=hourOfDay;
                    min2=minute;

                }
            }, ho, min, false);

            timePickerDialog.show();

        }
    }
}
package com.example.linta.birthdaybash;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Main3Activity extends AppCompatActivity {

    db1 mydb1;
    SQLiteDatabase db3;
    TextView t;

    String name, email;
    TextView t1, t2;
    ImageView img1;
    ListView lv;
    Context mContext;
    String tv, nv, nd, nt;
    ArrayAdapter ada;
    private ArrayList<String> list = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        mContext = this;
        lv = (ListView) findViewById(R.id.lv);
        mydb1 = new db1(this);
        db3 = mydb1.getWritableDatabase();
        Cursor d1 = db3.query("add1", null, null, null, null, null, null);
        if (d1.getCount() != 0) {
            d1.moveToFirst();
            int cc = d1.getCount();
            for (int i = 0; i < cc; i++) {
                tv = d1.getString((d1.getColumnIndex("name2")));
                nv = d1.getString((d1.getColumnIndex("phone2")));
                nd = d1.getString((d1.getColumnIndex("date2")));
                nt = d1.getString((d1.getColumnIndex("time2")));
                list.add(tv + "\n" + nv + "\n" + nd + "\t\t\t\t\t\t\t\t\t" + nt);
                d1.moveToNext();
            }

            ada = new ArrayAdapter<String>(mContext, android.R.layout.simple_list_item_1, list);
            lv.setAdapter(ada);
        }
    }
}
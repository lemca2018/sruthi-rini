package com.example.linta.birthdaybash;

import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Main4Activity extends AppCompatActivity {
    AlarmManager alarm_manager;
    PendingIntent pending_Intent;
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Calendar cal= Calendar.getInstance();
        int    d = cal.get(Calendar.DAY_OF_MONTH);
        int  m = cal.get(Calendar.MONTH);
        int  y = cal.get(Calendar.YEAR);
        int y1=y+1;

        int  min = cal.get(Calendar.MINUTE);
        int  ho = cal.get(Calendar.HOUR_OF_DAY);


        cal.set(Calendar.DATE,d);
        cal.set(Calendar.MONTH,m);
        cal.set(Calendar.YEAR,y1);

        cal.set(Calendar.HOUR_OF_DAY,ho);
        cal.set(Calendar.MINUTE,min);
        cal.set(Calendar.SECOND, 1);



        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(Main4Activity.this)
                .setContentText("New message")
                .setTicker("alert ne message");
        Intent alertIntent = new Intent(Main4Activity.this,alarmrec.class);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), PendingIntent.getBroadcast(Main4Activity.this, 1,alertIntent, PendingIntent.FLAG_UPDATE_CURRENT));
        pending_Intent =PendingIntent.getBroadcast(Main4Activity.this,0,alertIntent,PendingIntent.FLAG_UPDATE_CURRENT);
        Intent in=new Intent(Main4Activity.this,alarmrec.class);
        startActivity(in);
    }
}
